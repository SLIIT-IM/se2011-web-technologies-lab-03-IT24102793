let welcomeBtn = document.getElementById("welcomeBtn");
let welcomeMessage = document.getElementById("welcomeMessage");

welcomeBtn.onclick = function () {
    welcomeMessage.textContent = "Welcome to Campus Tech Store!";
};

let productTable = document.getElementById("productTable");
document.getElementById("productCount").textContent = productTable.rows.length - 1;

let discountBtn = document.getElementById("discountBtn");
discountBtn.onclick = function () {
    let price = Number(document.getElementById("priceInput").value);
    let result = document.getElementById("discountResult");

    if (price > 0) {
        let discount = price * 0.1;
        result.textContent = "Final Price: " + (price - discount);
    }
};

let products = ["Laptop", "Headphones", "Smart Watch", "USB Flash Drive"];

document.getElementById("searchBtn").onclick = function () {
    let input = document.getElementById("searchInput").value.toLowerCase();
    let found = products.includes(input.charAt(0).toUpperCase() + input.slice(1));
    document.getElementById("searchResult").textContent = found ? "Found" : "Not Found";
};

document.getElementById("showProductsBtn").onclick = function () {
    let list = document.getElementById("productListDisplay");
    list.innerHTML = "";
    products.forEach(p => list.innerHTML += "<li>" + p + "</li>");
};

document.getElementById("offersBtn").onclick = function () {
    document.getElementById("offersMessage").textContent = "Special offers available!";
};

document.getElementById("contactForm").onsubmit = function (e) {
    e.preventDefault();

    let name = fullname.value.trim();
    let email = email.value.trim();
    let phone = phone.value.trim();
    let msg = message.value.trim();

    let formMsg = document.getElementById("formMessage");

    if (!name || !email || !phone || !msg) {
        formMsg.textContent = "Fill all fields";
        formMsg.style.color = "red";
    } else {
        formMsg.textContent = "Success!";
        formMsg.style.color = "green";
    }
};

document.getElementById("themeBtn").onclick = function () {
    document.body.classList.toggle("dark-mode");
};

setInterval(() => {
    document.getElementById("clock").textContent = new Date().toLocaleTimeString();
}, 1000);